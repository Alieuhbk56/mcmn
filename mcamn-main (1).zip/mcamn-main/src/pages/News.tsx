import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin } from "lucide-react";

const News = () => {
  const events = [
    {
      title: "Annual Leadership Summit",
      date: "March 15, 2024",
      location: "Minneapolis Convention Center",
      category: "Conference",
      description: "Join us for our flagship event featuring keynote speakers, workshops, and networking opportunities focused on innovative county governance."
    },
    {
      title: "Regional Policy Forum",
      date: "April 22, 2024",
      location: "Rochester Community Center",
      category: "Forum",
      description: "A focused discussion on current policy challenges and opportunities facing Minnesota counties, with expert panelists and interactive sessions."
    },
    {
      title: "Professional Development Workshop",
      date: "May 10, 2024",
      location: "St. Cloud Civic Center",
      category: "Workshop",
      description: "Enhance your skills with training sessions on leadership, communication, and effective county management practices."
    },
    {
      title: "Quarterly Networking Mixer",
      date: "June 5, 2024",
      location: "Duluth Waterfront",
      category: "Social",
      description: "Connect with fellow county officials and community leaders in a relaxed, informal setting by the beautiful Duluth waterfront."
    },
  ];

  const news = [
    {
      title: "Chapter Celebrates 10 Years of Service Excellence",
      date: "February 28, 2024",
      excerpt: "Looking back on a decade of supporting Minnesota counties through professional development, advocacy, and community building."
    },
    {
      title: "New Partnership Announced with State Government",
      date: "February 15, 2024",
      excerpt: "Strengthening collaboration to improve county-state coordination and resource sharing across Minnesota."
    },
    {
      title: "Grant Program Launches to Support Rural Counties",
      date: "January 30, 2024",
      excerpt: "New funding initiative aims to provide resources for innovation and capacity building in rural county governments."
    },
  ];

  return (
    <div className="flex flex-col">
      {/* Header Section */}
      <section className="bg-gradient-to-r from-primary to-primary-hover text-primary-foreground py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">News & Events</h1>
          <p className="text-xl opacity-90 max-w-2xl mx-auto">
            Stay informed about upcoming events, latest news, and important updates from our chapter.
          </p>
        </div>
      </section>

      {/* Upcoming Events */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-foreground">Upcoming Events</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {events.map((event, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <Badge variant="secondary">{event.category}</Badge>
                  </div>
                  <CardTitle className="text-xl">{event.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center text-muted-foreground">
                      <Calendar className="h-4 w-4 mr-2" />
                      <span className="text-sm">{event.date}</span>
                    </div>
                    <div className="flex items-center text-muted-foreground">
                      <MapPin className="h-4 w-4 mr-2" />
                      <span className="text-sm">{event.location}</span>
                    </div>
                  </div>
                  <CardDescription className="text-base">
                    {event.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Latest News */}
      <section className="py-16 bg-secondary">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-foreground">Latest News</h2>
          <div className="space-y-6 max-w-4xl">
            {news.map((item, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <span className="text-sm text-muted-foreground">{item.date}</span>
                  </div>
                  <CardTitle className="text-xl">{item.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {item.excerpt}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4 text-foreground">Stay Updated</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Subscribe to our newsletter to receive the latest news, event announcements, 
              and updates from the Minnesota Chapter.
            </p>
            <Card className="bg-secondary">
              <CardContent className="pt-6">
                <p className="text-muted-foreground">
                  Contact us to join our mailing list and stay connected with our community.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

export default News;
