import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { History, Target, Heart } from "lucide-react";

const About = () => {
  return (
    <div className="flex flex-col">
      {/* Header Section */}
      <section className="bg-gradient-to-r from-primary to-primary-hover text-primary-foreground py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">About Our Chapter</h1>
          <p className="text-xl opacity-90 max-w-2xl mx-auto">
            Serving Minnesota counties with dedication, integrity, and excellence since our founding.
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <Card className="mb-8">
            <CardHeader>
              <div className="flex items-center space-x-3 mb-2">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <History className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-2xl">Our History</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base leading-relaxed">
                The Minnesota Chapter of the Maryland County Association was established to provide 
                a dedicated platform for Minnesota county officials and community leaders. Building 
                on the national organization's legacy, our chapter has grown into a vital resource 
                for promoting effective county governance, fostering professional development, and 
                facilitating collaboration among Minnesota's diverse counties.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <div className="flex items-center space-x-3 mb-2">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Target className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-2xl">Our Vision</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base leading-relaxed">
                We envision a Minnesota where every county thrives through innovative leadership, 
                collaborative partnerships, and responsive governance. Our chapter strives to be 
                the premier organization supporting county officials in their mission to serve 
                their communities with excellence and integrity.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center space-x-3 mb-2">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Heart className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-2xl">Our Values</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <span className="inline-block w-2 h-2 bg-accent rounded-full mt-2 mr-3 flex-shrink-0" />
                  <CardDescription className="text-base">
                    <strong className="text-foreground">Integrity:</strong> Upholding the highest ethical 
                    standards in all our activities and interactions.
                  </CardDescription>
                </li>
                <li className="flex items-start">
                  <span className="inline-block w-2 h-2 bg-accent rounded-full mt-2 mr-3 flex-shrink-0" />
                  <CardDescription className="text-base">
                    <strong className="text-foreground">Collaboration:</strong> Fostering partnerships 
                    and teamwork to achieve common goals.
                  </CardDescription>
                </li>
                <li className="flex items-start">
                  <span className="inline-block w-2 h-2 bg-accent rounded-full mt-2 mr-3 flex-shrink-0" />
                  <CardDescription className="text-base">
                    <strong className="text-foreground">Excellence:</strong> Committing to continuous 
                    improvement and best practices in county governance.
                  </CardDescription>
                </li>
                <li className="flex items-start">
                  <span className="inline-block w-2 h-2 bg-accent rounded-full mt-2 mr-3 flex-shrink-0" />
                  <CardDescription className="text-base">
                    <strong className="text-foreground">Service:</strong> Dedicating ourselves to 
                    supporting county officials and the communities they serve.
                  </CardDescription>
                </li>
                <li className="flex items-start">
                  <span className="inline-block w-2 h-2 bg-accent rounded-full mt-2 mr-3 flex-shrink-0" />
                  <CardDescription className="text-base">
                    <strong className="text-foreground">Innovation:</strong> Embracing new ideas 
                    and approaches to address evolving challenges.
                  </CardDescription>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Leadership Section */}
      <section className="py-16 bg-secondary">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">Leadership</h2>
          <div className="max-w-2xl mx-auto text-center">
            <CardDescription className="text-base leading-relaxed">
              Our chapter is led by a dedicated board of county officials and community leaders 
              who bring decades of combined experience in public service and county governance. 
              Together, they guide our mission to strengthen Minnesota counties and support the 
              professionals who serve them.
            </CardDescription>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
